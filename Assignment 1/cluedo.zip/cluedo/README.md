# I-Hate-C
Swen225 Cluedo Assignment 1
